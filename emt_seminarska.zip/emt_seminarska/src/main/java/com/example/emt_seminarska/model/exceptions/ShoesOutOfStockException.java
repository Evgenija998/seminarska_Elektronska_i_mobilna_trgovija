package com.example.emt_seminarska.model.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.PRECONDITION_FAILED)
public class ShoesOutOfStockException extends RuntimeException {
    public ShoesOutOfStockException(String name) {
        super(String.format("Shoes %s are out of stock!", name));
    }
}
