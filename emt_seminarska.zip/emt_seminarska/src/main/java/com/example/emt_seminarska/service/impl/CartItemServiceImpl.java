package com.example.emt_seminarska.service.impl;

import com.example.emt_seminarska.model.CartItem;
import com.example.emt_seminarska.model.exceptions.CartItemNotFoundException;
import com.example.emt_seminarska.repository.CartItemRepository;
import com.example.emt_seminarska.service.CartItemService;
import org.springframework.stereotype.Service;

@Service
public class CartItemServiceImpl implements CartItemService {

    private final CartItemRepository cartItemRepository;

    public CartItemServiceImpl(CartItemRepository cartItemRepository) {
        this.cartItemRepository = cartItemRepository;
    }

    @Override
    public CartItem findById(Long cartItemId) {
        return this.cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new CartItemNotFoundException(cartItemId));
    }
}
