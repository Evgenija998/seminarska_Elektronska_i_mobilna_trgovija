package com.example.emt_seminarska.model.enumerations;

public enum CartStatus {
    CREATED, CANCELED, FINISHED, CLOSED
}
