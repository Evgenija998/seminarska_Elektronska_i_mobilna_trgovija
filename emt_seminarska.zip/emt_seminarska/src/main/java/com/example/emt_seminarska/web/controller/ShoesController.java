package com.example.emt_seminarska.web.controller;

import com.example.emt_seminarska.model.Category;
import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.model.exceptions.ShoesAreAlreadyInShoppingCartException;
import com.example.emt_seminarska.repository.BrandRepository;
import com.example.emt_seminarska.service.CategoryService;
import com.example.emt_seminarska.service.ShoesService;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/shoes")
public class ShoesController {
    private final ShoesService shoesService;
    private final CategoryService categoryService;
    private final BrandRepository brandRepository;

    public ShoesController(ShoesService shoesService, CategoryService categoryService, BrandRepository brandRepository){
        this.shoesService = shoesService;
        this.categoryService = categoryService;
        this.brandRepository = brandRepository;
    }

    @GetMapping
    public String getShoesPage(Model model){
        List<Shoes> shoes = this.shoesService.findAll();
        model.addAttribute("shoes", shoes);
        return "shoes";
    }

    @GetMapping("/new")
    public String addNewShoesPage(Model model) {
        List<Category> categories = this.categoryService.findAll();
        model.addAttribute("categories", categories);
        model.addAttribute("brands", this.brandRepository.findAll());
        model.addAttribute("shoes", new Shoes());
        return "add-shoes";
    }

    @GetMapping("/{id}/edit")
    public String editShoesPage(Model model, @PathVariable Long id) {
        try {
            Shoes shoes = this.shoesService.findById(id);
            List<Category> categories = this.categoryService.findAll();
            model.addAttribute("shoes", shoes);
            model.addAttribute("categories", categories);
            model.addAttribute("brands", this.brandRepository.findAll());
            return "add-shoes";
        } catch (RuntimeException ex) {
            return "redirect:/shoes?error=" + ex.getMessage();
        }
    }

    @PostMapping
    @Secured("ROLE_ADMIN")
    public String saveShoes(
            @Valid Shoes shoes,
            BindingResult bindingResult,
            @RequestParam MultipartFile image,
            Model model) {

        if (bindingResult.hasErrors()) {
            List<Category> categories = this.categoryService.findAll();
            model.addAttribute("categories", categories);
            model.addAttribute("brands", this.brandRepository.findAll());
            return "add-shoes";
        }
        try {
            this.shoesService.saveShoes(shoes, image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "redirect:/shoes";
    }

    @PostMapping("/{id}/delete")
    public String deleteShoesWithPost(@PathVariable Long id) {
        try {
            this.shoesService.deleteById(id);
        } catch (ShoesAreAlreadyInShoppingCartException ex) {
            return String.format("redirect:/shoes?error=%s", ex.getMessage());
        }
        return "redirect:/shoes";
    }

    @DeleteMapping("/{id}/delete")
    public String deleteShoesWithDelete(@PathVariable Long id) {
        this.shoesService.deleteById(id);
        return "redirect:/shoes";
    }
}
