package com.example.emt_seminarska.service.impl;

import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.model.exceptions.UserAlreadyExistsException;
import com.example.emt_seminarska.model.exceptions.UserNotFoundException;
import com.example.emt_seminarska.repository.UserRepository;
import com.example.emt_seminarska.service.UserService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User findById(String userId) {
        return this.userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
    }

    @Override
    public User registerUser(User user) {
        if (this.userRepository.existsById(user.getUsername())) {
            throw new UserAlreadyExistsException(user.getUsername());
        }
        return this.userRepository.save(user);
    }

    @Override
    public List<Shoes> fetchUserProductCart() {

        return userRepository.findAll()
                .stream()
                .findFirst()
                .get()
                .getOrder();
    }

    @Override
    public void deleteProduct(String id) {
        User u = userRepository.findAll()
                .stream()
                .findFirst()
                .get();

        Shoes s = u.getOrder()
                .stream()
                .filter(product -> product.getId().equals(id))
                .findFirst()
                .get();
        u.getOrder().remove(s);

        userRepository.save(u);
    }

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        return this.userRepository.findById(s)
                .orElseThrow(() -> new UsernameNotFoundException(s));
    }
}
