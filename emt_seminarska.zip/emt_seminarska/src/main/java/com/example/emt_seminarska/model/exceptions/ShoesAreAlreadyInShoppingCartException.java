package com.example.emt_seminarska.model.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.PRECONDITION_FAILED)
public class ShoesAreAlreadyInShoppingCartException extends RuntimeException{
    public ShoesAreAlreadyInShoppingCartException(String shoesName) {
        super(String.format("Shoes %s are already in active shopping cart", shoesName));
    }
}
