package com.example.emt_seminarska.model.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND)
public class ShoesNotFoundException extends RuntimeException{
    public ShoesNotFoundException(Long id) {
        super(String.format("Shoes with %d were not found!", id));
    }
}
