package com.example.emt_seminarska.service;

import com.example.emt_seminarska.model.ShoppingCart;
import com.example.emt_seminarska.model.dto.ChargeRequest;

import java.util.List;
import java.util.Optional;

public interface ShoppingCartService {
    ShoppingCart findActiveShoppingCartByUsername(String userId);
    List<ShoppingCart> findAllByUsername(String userId);
    ShoppingCart createNewShoppingCart(String userId);
    ShoppingCart closeActiveShoppingCart(String userId);
    ShoppingCart addShoesToShoppingCart(String userId, Long shoesId);
    ShoppingCart removeShoesFromShoppingCart(String userId, Long shoesId);
    ShoppingCart getActiveShoppingCart(String userId);
    ShoppingCart cancelActiveShoppingCart(String userId);
    ShoppingCart checkoutShoppingCart(String userId, ChargeRequest chargeRequest);
    //void deleteProduct(String productId);
    //Optional<ShoppingCart> findProductById(Long id);
}
