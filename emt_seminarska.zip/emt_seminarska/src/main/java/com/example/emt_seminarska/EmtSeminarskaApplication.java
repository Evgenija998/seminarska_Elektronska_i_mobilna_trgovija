package com.example.emt_seminarska;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmtSeminarskaApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmtSeminarskaApplication.class, args);
    }

}
