package com.example.emt_seminarska.service;

import com.example.emt_seminarska.model.CartItem;

public interface CartItemService {
    CartItem findById(Long cartItemId);
}
