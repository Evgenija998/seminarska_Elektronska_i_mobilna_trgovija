package com.example.emt_seminarska.web.controller;

import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService userInterface;

    public UserController(UserService userInterface) {
        this.userInterface = userInterface;
    }



    @GetMapping("/get-cart-products")
    private String userCart(HttpSession session) {
        session.setAttribute("userCart", userInterface.fetchUserProductCart());
        session.setAttribute("totalPrice", userInterface.fetchUserProductCart()
                .stream()
                .mapToInt(Shoes::getPrice).sum());
        session.setAttribute("currency","DOLLAR" );
        session.setAttribute("STRIPE_P_KEY" ,"pk_test_51HhKl1CP6nqkPriJ8q3S74sAJJeQgsRnqQWKDEBsuPVGxO5uBmhuhQxzdcizWTgoanPvSWfx7g75Sc1oJ3PvfcHZ00ROrjOUFD");
        return "cart";
    }

    @GetMapping("/delete-product/{id}")
    private String deleteProduct(@PathVariable String id) {
        userInterface.deleteProduct(id);
        return "redirect:/user/get-cart-products";
    }

}