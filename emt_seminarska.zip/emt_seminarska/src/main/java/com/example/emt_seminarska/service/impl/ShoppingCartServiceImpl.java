package com.example.emt_seminarska.service.impl;

import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.model.ShoppingCart;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.model.dto.ChargeRequest;
import com.example.emt_seminarska.model.enumerations.CartStatus;
import com.example.emt_seminarska.model.exceptions.*;
import com.example.emt_seminarska.repository.ShoesRepository;
import com.example.emt_seminarska.repository.ShoppingCartRepository;
import com.example.emt_seminarska.repository.UserRepository;
import com.example.emt_seminarska.service.PaymentService;
import com.example.emt_seminarska.service.ShoesService;
import com.example.emt_seminarska.service.ShoppingCartService;
import com.example.emt_seminarska.service.UserService;
import com.stripe.exception.*;
import com.stripe.model.Charge;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {

    private final UserService userService;
    private final ShoesService shoesService;
    private final ShoppingCartRepository shoppingCartRepository;
    private final PaymentService paymentService;


    public ShoppingCartServiceImpl(UserService userService, ShoesService shoesService, ShoppingCartRepository shoppingCartRepository, PaymentService paymentService) {
        this.userService = userService;
        this.shoesService = shoesService;
        this.shoppingCartRepository = shoppingCartRepository;
        this.paymentService = paymentService;
    }

    @Override
    public ShoppingCart findActiveShoppingCartByUsername(String userId) {
        return this.shoppingCartRepository.findByUserUsernameAndStatus(userId, CartStatus.CREATED)
                .orElseThrow(() -> new ShoppingCartIsNotActiveException(userId));
    }

    @Override
    public List<ShoppingCart> findAllByUsername(String userId) {
        return this.shoppingCartRepository.findAllByUserUsername(userId);
    }

    @Override
    public ShoppingCart createNewShoppingCart(String userId) {
        User user = this.userService.findById(userId);
        if (this.shoppingCartRepository.existsByUserUsernameAndStatus(
                user.getUsername(),
                CartStatus.CREATED
        )) {
            throw new ShoppingCartAlreadyCreated(userId);
        }
        ShoppingCart shoppingCart = new ShoppingCart();
        shoppingCart.setUser(user);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart closeActiveShoppingCart(String userId) {
        ShoppingCart shoppingCart = this.shoppingCartRepository.
                findByUserUsernameAndStatus(userId, CartStatus.CREATED)
                .orElseThrow(() -> new ShoppingCartIsNotActiveException(userId));
        shoppingCart.setStatus(CartStatus.CLOSED);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart addShoesToShoppingCart(String userId, Long shoesId) {
        ShoppingCart shoppingCart = this.getActiveShoppingCart(userId);
        Shoes shoes = this.shoesService.findById(shoesId);
        for (Shoes s : shoppingCart.getShoes()) {
            if (s.getId().equals(shoesId)) {
                throw new ShoesAreAlreadyInShoppingCartException(shoes.getName());
            }
        }
        shoppingCart.getShoes().add(shoes);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart removeShoesFromShoppingCart(String userId, Long shoesId) {
        ShoppingCart shoppingCart = this.getActiveShoppingCart(userId);
        shoppingCart.setShoes(
                shoppingCart.getShoes()
                        .stream()
                        .filter(shoes -> !shoes.getId().equals(shoesId))
                        .collect(Collectors.toList())
        );
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart getActiveShoppingCart(String userId) {
        return this.shoppingCartRepository
                .findByUserUsernameAndStatus(userId, CartStatus.CREATED)
                .orElseGet(() -> {
                    ShoppingCart shoppingCart = new ShoppingCart();
                    User user = this.userService.findById(userId);
                    shoppingCart.setUser(user);
                    return  this.shoppingCartRepository.save(shoppingCart);
                });
    }

    @Override
    public ShoppingCart cancelActiveShoppingCart(String userId) {
        ShoppingCart shoppingCart = this.shoppingCartRepository
                .findByUserUsernameAndStatus(userId, CartStatus.CREATED)
                .orElseThrow(() -> new ShoppingCartIsNotActiveException(userId));
        shoppingCart.setStatus(CartStatus.CANCELED);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    @Transactional
    public ShoppingCart checkoutShoppingCart(String userId, ChargeRequest chargeRequest) {
        ShoppingCart shoppingCart = this.shoppingCartRepository
                .findByUserUsernameAndStatus(userId, CartStatus.CREATED)
                .orElseThrow(() -> new ShoppingCartIsNotActiveException(userId));

        List<Shoes> shoes = shoppingCart.getShoes();

        for (Shoes shoe : shoes) {
            if (shoe.getQuantity() <= 0) {
                throw new ShoesOutOfStockException(shoe.getName());
            }
            shoe.setQuantity(shoe.getQuantity() - 1);
        }
        Charge charge = null;
        try {
            charge = this.paymentService.pay(chargeRequest);
        } catch (CardException | APIException | AuthenticationException | APIConnectionException | InvalidRequestException e) {
            throw new TransactionFailedException(userId, e.getMessage());
        }
        shoppingCart.setShoes(shoes);
        shoppingCart.setStatus(CartStatus.FINISHED);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    /* @Override
    public void deleteProduct(String productId) {
        Shoes deleteProduct = ShoesRepository.findById(productId).get();

        User u = UserRepository.findAll().stream()
                .findFirst()
                .get();
        u.getOrder().remove(deleteProduct);
        UserRepository.save(u);
    } */
}
