package com.example.emt_seminarska.web.controller;

import com.example.emt_seminarska.model.ShoppingCart;
import com.example.emt_seminarska.service.AuthenticationService;
import com.example.emt_seminarska.service.ShoppingCartService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/shopping-carts")
public class ShoppingCartController {

    private final ShoppingCartService shoppingCartService;
    private final AuthenticationService authenticationService;

    public ShoppingCartController(ShoppingCartService shoppingCartService,
                                  AuthenticationService authenticationService) {
        this.shoppingCartService = shoppingCartService;
        this.authenticationService = authenticationService;
    }


    @PostMapping("/{shoesId}/add-shoes")
    public String addProductToShoppingCart(@PathVariable Long shoesId) {
        try {
            ShoppingCart shoppingCart = this.shoppingCartService.addShoesToShoppingCart(this.authenticationService.getCurrentUserId(), shoesId);
        } catch (RuntimeException ex) {
            return "redirect:/shoes?error=" + ex.getLocalizedMessage();
        }
        return "redirect:/shoes";
    }


    @PostMapping("/{shoesId}/remove-product")
    public String removeProductToShoppingCart(@PathVariable Long shoesId) {
        ShoppingCart shoppingCart = this.shoppingCartService.removeShoesFromShoppingCart(this.authenticationService.getCurrentUserId(), shoesId);
        return "redirect:/shoes";
    }

    /*@PostMapping("/delete-product/{id}")
    private String deleteProduct(@PathVariable String id) {
        shoppingCartService.deleteProduct(id);
        return "redirect:/user/get-cart-products";
    }*/
}
