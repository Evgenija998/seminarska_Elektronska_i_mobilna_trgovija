package com.example.emt_seminarska.service;

import com.example.emt_seminarska.model.Shoes;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ShoesService {
    List<Shoes> findAll();
    List<Shoes> findAllByCategoryId(Long categoryId);
    Shoes findById(Long id);
    Shoes saveShoes(String name, Integer quantity, Long categoryId);
    Shoes saveShoes(Shoes shoes, MultipartFile image) throws IOException;
    Shoes updateShoes(Long id, Shoes shoes, MultipartFile image) throws IOException;
    void deleteById(Long id);
    //void addToCartProduct(Long id);
}
