package com.example.emt_seminarska.service.impl;

import com.example.emt_seminarska.model.Category;
import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.model.exceptions.ShoesNotFoundException;
import com.example.emt_seminarska.repository.ShoesRepository;
import com.example.emt_seminarska.repository.UserRepository;
import com.example.emt_seminarska.service.BrandService;
import com.example.emt_seminarska.service.CategoryService;
import com.example.emt_seminarska.service.ShoesService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

@Service
public class ShoesServiceImpl implements ShoesService {
    private final ShoesRepository shoesRepository;
    private final CategoryService categoryService;
    private final BrandService brandService;

    public ShoesServiceImpl(ShoesRepository shoesRepository, CategoryService categoryService, BrandService brandService) {
        this.shoesRepository = shoesRepository;
        this.categoryService = categoryService;
        this.brandService = brandService;
    }

    @Override
    public List<Shoes> findAll() {
        return this.shoesRepository.findAll();
    }

    @Override
    public List<Shoes> findAllByCategoryId(Long categoryId) {
        return this.shoesRepository.findAllByCategoryId(categoryId);
    }

    @Override
    public Shoes findById(Long id) {
        return this.shoesRepository.findById(id).orElseThrow(() -> new ShoesNotFoundException(id));
    }

    @Override
    public Shoes saveShoes(String name, Integer quantity, Long categoryId) {
        Category category = this.categoryService.findById(categoryId);
        Shoes shoes = new Shoes(null, name, quantity, category);
        return this.shoesRepository.save(shoes);
    }


    @Override
    public Shoes saveShoes(Shoes shoes, MultipartFile image) throws IOException {
        Category category = this.categoryService.findById(shoes.getCategory().getId());
        shoes.setCategory(category);
        if (image != null && !image.getName().isEmpty()) {
            byte[] bytes = image.getBytes();
            String base64Image = String.format("data:%s;base64,%s", image.getContentType(), Base64.getEncoder().encodeToString(bytes));
            shoes.setImageBase64(base64Image);
        }
        return this.shoesRepository.save(shoes);
    }

    @Override
    public Shoes updateShoes(Long id, Shoes shoes, MultipartFile image) throws IOException {
        Shoes s = this.findById(id);
        Category category = this.categoryService.findById(shoes.getCategory().getId());
        s.setCategory(category);
        s.setQuantity(shoes.getQuantity());
        if (image != null && !image.getName().isEmpty()) {
            byte[] bytes = image.getBytes();
            String base64Image = String.format("data:%s;base64,%s", image.getContentType(), Base64.getEncoder().encodeToString(bytes));
            s.setImageBase64(base64Image);
        }
        return this.shoesRepository.save(s);
    }

    @Override
    public void deleteById(Long id) {
        this.shoesRepository.deleteById(id);
    }

    /*@Override
    public void addToCartProduct(Long id) {
        User u = UserRepository.findAll().stream()
                .findFirst()
                .get();
        u.getOrder().add(findById(id));

        UserRepository.save(u);
    }*/
}
