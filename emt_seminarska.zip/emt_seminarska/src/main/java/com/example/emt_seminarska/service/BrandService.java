package com.example.emt_seminarska.service;

import com.example.emt_seminarska.model.Brand;

public interface BrandService {
    Brand findById(Long authorId);
}
