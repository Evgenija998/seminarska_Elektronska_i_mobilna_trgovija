package com.example.emt_seminarska.service.impl;

import com.example.emt_seminarska.model.Brand;
import com.example.emt_seminarska.model.exceptions.BrandNotFoundException;
import com.example.emt_seminarska.repository.BrandRepository;
import com.example.emt_seminarska.service.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BrandServiceImpl implements BrandService {
    private final BrandRepository brandRepository;

    @Autowired
    public BrandServiceImpl(BrandRepository brandRepository) {
        this.brandRepository = brandRepository;
    }

    @Override
    public Brand findById(Long brandId) {
        return this.brandRepository.findById(brandId)
                .orElseThrow(() -> new BrandNotFoundException(brandId));
    }
}
