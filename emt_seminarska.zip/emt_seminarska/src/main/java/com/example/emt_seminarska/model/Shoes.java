package com.example.emt_seminarska.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import java.util.List;
import java.util.Locale;

@Entity
@Table(name = "shoes")
public class Shoes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @PositiveOrZero
    private Integer quantity;

    @NotNull
    @ManyToOne
    private Category category;

    @JsonIgnore
    @OneToMany(mappedBy = "shoe")
    List<CartItem> cartItems;

    @JsonIgnore
    @ManyToMany(mappedBy = "shoes")
    private List<ShoppingCart> shoppingCarts;

    @JsonIgnore
    @ManyToMany(mappedBy = "shoes")
    private List<Brand> brands;

    @Column(name = "image")
    @Lob
    private String imageBase64;

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    private int price;

    public Shoes() {
    }

    public Shoes(Long id, String name, Integer quantity, Category category) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.category = category;
    }

    @ManyToMany(mappedBy = "order")
    private List<User> userOrders;

    public List<User> getUserOrders() {
        return userOrders;
    }

    public void setUserOrders(List<User> userOrders) {
        this.userOrders = userOrders;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public List<Brand> getBrands() {
        return brands;
    }

    public void setBrands(List<Brand> brands) {
        this.brands = brands;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public void setImageBase64(String imageBase64) {
        this.imageBase64 = imageBase64;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public List<ShoppingCart> getShoppingCarts() {
        return shoppingCarts;
    }

    public void setShoppingCarts(List<ShoppingCart> shoppingCarts) {
        this.shoppingCarts = shoppingCarts;
    }
}
