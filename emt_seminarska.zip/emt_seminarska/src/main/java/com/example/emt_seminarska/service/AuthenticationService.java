package com.example.emt_seminarska.service;

import com.example.emt_seminarska.model.User;

public interface AuthenticationService {
    User getCurrentUser();
    String getCurrentUserId();
    User signUpUser(String username, String password, String repeatedPassword);
}
