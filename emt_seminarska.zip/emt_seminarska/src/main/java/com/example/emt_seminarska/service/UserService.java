package com.example.emt_seminarska.service;

import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.model.User;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
    User findById(String userId);
    User registerUser(User user);
    List<Shoes> fetchUserProductCart();
    void deleteProduct(String id);
}
