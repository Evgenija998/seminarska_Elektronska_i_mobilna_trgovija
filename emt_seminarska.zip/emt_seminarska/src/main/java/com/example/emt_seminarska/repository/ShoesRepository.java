package com.example.emt_seminarska.repository;

import com.example.emt_seminarska.model.Shoes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShoesRepository extends JpaRepository<Shoes, Long> {
    List<Shoes> findAllByCategoryId(@Param("id") Long id);
    Optional<Shoes> findById(String id);
}
