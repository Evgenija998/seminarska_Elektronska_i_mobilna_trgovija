package com.example.emt_seminarska.web.rest_controller;

import com.example.emt_seminarska.model.Shoes;
import com.example.emt_seminarska.service.ShoesService;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/shoes")
public class ShoesRestController {
    private final ShoesService shoesService;

    public ShoesRestController(ShoesService shoesService) {
        this.shoesService = shoesService;
    }

    @GetMapping
    @Secured("ROLE_ADMIN")
    public List<Shoes> findAll() {
        return this.shoesService.findAll();
    }

    @GetMapping("/{id}")
    public Shoes findById(@PathVariable Long id) {
        return this.shoesService.findById(id);
    }

    @GetMapping("/by-category/{categoryId}")
    public List<Shoes> findAllByCategoryId(@PathVariable Long categoryId) {
        return this.shoesService.findAllByCategoryId(categoryId);
    }

    @PostMapping
    public Shoes save(@Valid Shoes shoes, @RequestParam(required = false) MultipartFile image) throws IOException {
        return this.shoesService.saveShoes(shoes, image);
    }

    @PutMapping("/{id}")
    public Shoes update(@PathVariable Long id, @Valid Shoes shoes, @RequestParam(required = false) MultipartFile image) throws IOException {
        return this.shoesService.updateShoes(id, shoes, image);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        this.shoesService.deleteById(id);
    }
}
