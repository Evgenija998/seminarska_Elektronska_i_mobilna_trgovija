package com.example.emt_seminarska.web.rest_controller;

import com.example.emt_seminarska.model.ShoppingCart;
import com.example.emt_seminarska.service.AuthenticationService;
import com.example.emt_seminarska.service.ShoppingCartService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shopping-carts")
public class ShoppingCartRestController {

    private final ShoppingCartService shoppingCartService;
    private final AuthenticationService authenticationService;

    public ShoppingCartRestController(ShoppingCartService shoppingCartService,
                                      AuthenticationService authenticationService) {
        this.shoppingCartService = shoppingCartService;
        this.authenticationService = authenticationService;
    }

    @PostMapping
    public ShoppingCart createNewShoppingCart() {
        return this.shoppingCartService.createNewShoppingCart(this.authenticationService.getCurrentUserId());
    }

    @DeleteMapping("{cartId}/shopping-carts")
    public ShoppingCart closeActiveShoppingCart(){
        return this.shoppingCartService.closeActiveShoppingCart(
                this.authenticationService.getCurrentUserId());
    }

    @GetMapping
    public List<ShoppingCart> findAllByUsername() {
        return  this.shoppingCartService.findAllByUsername(this.authenticationService.getCurrentUserId());
    }

    @PatchMapping("/{shoesId}/shoes")
    public ShoppingCart addShoesToCart(@PathVariable Long shoesId) {
        return this.shoppingCartService.addShoesToShoppingCart(
                this.authenticationService.getCurrentUserId(),
                shoesId
        );
    }

    @DeleteMapping("/{shoesId}/shoes")
    public ShoppingCart removeShoesFromCart(@PathVariable Long shoesId) {
        return this.shoppingCartService.removeShoesFromShoppingCart(
                this.authenticationService.getCurrentUserId(),
                shoesId
        );
    }

    @PatchMapping("/cancel")
    public ShoppingCart cancelActiveShoppingCart() {
        return this.shoppingCartService.cancelActiveShoppingCart(
                this.authenticationService.getCurrentUserId());
    }

    @PatchMapping("/checkout")
    public ShoppingCart checkoutActiveShoppingCart() {
        return null;
    }
}
