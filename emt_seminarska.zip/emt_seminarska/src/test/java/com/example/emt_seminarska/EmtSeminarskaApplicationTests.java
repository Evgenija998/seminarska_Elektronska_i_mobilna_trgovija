package com.example.emt_seminarska;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmtSeminarskaApplicationTests {

    @Test
    void contextLoads() {
    }

}
